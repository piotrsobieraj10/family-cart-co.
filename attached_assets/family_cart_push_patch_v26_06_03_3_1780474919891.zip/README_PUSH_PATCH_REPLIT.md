# Family Cart — Push notifications patch v26.06.03.3

Ten patch dodaje moduł powiadomień push PWA do aktualnej aplikacji Family Cart.

## Zakres

- sekcja `Powiadomienia` w Ustawieniach,
- włączanie i wyłączanie subskrypcji push,
- preferencje typów powiadomień,
- `public/push-sw.js` z obsługą `push` i `notificationclick`,
- `src/lib/push.ts` z helperami frontendu,
- migracja `supabase/migrations/20260603140000_push_notifications.sql`,
- Edge Functions:
  - `save-push-subscription`,
  - `delete-push-subscription`,
  - `send-push-notification`,
- wysyłka best-effort po dodaniu produktu, zakończeniu zakupów i zmianie członków domu,
- dopisek w polityce prywatności o powiadomieniach push,
- aktualizacja `.env.example`, `LOVEABLE_PATCH.md` i `supabase/config.toml`.

## Wymagane zmienne

Frontend:

```env
VITE_VAPID_PUBLIC_KEY=
```

Supabase Edge Functions:

```env
VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=
VAPID_SUBJECT=mailto:[UZUPEŁNIJ_ADRES_EMAIL]
```

`VAPID_PRIVATE_KEY` nie może trafić do frontendu, `VITE_*`, repozytorium ani plików publicznych.

## Wdrożenie

1. Skopiuj pliki patcha do projektu.
2. Zastosuj migrację SQL:

```bash
supabase db push
```

3. Wdróż funkcje:

```bash
supabase functions deploy save-push-subscription
supabase functions deploy delete-push-subscription
supabase functions deploy send-push-notification
```

4. Ustaw zmienne VAPID w środowisku frontendu i Edge Functions.
5. Opublikuj aplikację na HTTPS.
6. Przetestuj powiadomienia na opublikowanej domenie PWA.

## Testy

- TypeScript/build/lint powinny zostać uruchomione w Replit po wgraniu patcha.
- Prawdziwy test push wymaga HTTPS i poprawnych kluczy VAPID.
- W środowisku lokalnym bez HTTPS można sprawdzić UI, zapis ustawień i brak błędów kompilacji.

## TODO

- Pełne przypomnienia cykliczne i powiadomienia o zapasach z kończącym się terminem ważności.
- Panel administracyjny historii push.
- Ewentualne powiadomienia o kolejnych zdarzeniach aplikacji.
