# Family Cart — patch do Loveable v26.06.03.2

Ta paczka zawiera tylko pliki nowe i zmienione względem wcześniejszej paczki `family-cart-co.-main.zip`.

## Jak użyć

1. W Loveable / edytorze projektu wgraj lub podmień pliki z tej paczki, zachowując te same ścieżki katalogów.
2. Nie kopiuj `node_modules`, `dist`, `.git` ani produkcyjnego `.env`.
3. Przeczytaj `LOVEABLE_PATCH.md` — zawiera instrukcję migracji Supabase, Edge Functions, zmiennych i testów.
4. Zastosuj migracje Supabase w kolejności wskazanej w `LOVEABLE_PATCH.md`.
5. Wdróż wymagane Edge Functions.
6. Ustaw zmienne środowiskowe w Loveable/Supabase zgodnie z `LOVEABLE_PATCH.md` oraz `.env.example`.

## Najważniejsze zmiany w tej paczce

- Family Cart / Version: v26.06.03.1 / Created by: AutoSafe.
- Wybór motywu: Auto / Jasny / Ciemny.
- Wybór języka: Polski / English.
- System i18n: `src/i18n/*`.
- System motywu: `src/theme/index.ts`.
- Aktualizacja `LOVEABLE_PATCH.md`.
- Pełny zestaw wcześniejszych zmian patcha: domy/grupy, RLS, rejestracja, szybkie listy, sklepy, ceny, paragony.

## Zawartość

Lista plików znajduje się w `PATCH_CHANGED_FILES.txt`.

## Bezpieczeństwo

Paczka nie zawiera:
- `node_modules/`,
- `dist/`,
- `.git/`,
- produkcyjnego `.env`,
- sekretów Supabase.

`SUPABASE_SERVICE_ROLE_KEY` ma być ustawiony wyłącznie po stronie Supabase Edge Functions, nigdy w frontendzie ani `VITE_*`.
