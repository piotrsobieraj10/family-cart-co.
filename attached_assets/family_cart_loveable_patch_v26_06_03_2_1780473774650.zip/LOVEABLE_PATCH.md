# Family Cart - patch aplikacji

## Uzupełnienie: nazwa, wersja, autor i polityka prywatności

- Główna nazwa aplikacji: `Family Cart`.
- Wersja aplikacji: `v26.06.03.1`.
- Tekst autora: `Created by: AutoSafe`.
- Wspólne wartości znajdują się w `src/config/app.ts`.
- Ekrany logowania, rejestracji, ustawień, „O aplikacji”, „Co nowego” i polityki prywatności pokazują aktualne dane aplikacji.
- Polityka prywatności ma wersję `1.1`, datę aktualizacji `2026-06-03` i placeholdery wymagające uzupełnienia przed publikacją.

Finalny zapis identyfikacji aplikacji:

```text
Family Cart
Version: v26.06.03.1
Created by: AutoSafe
```

## Zakres

- Wiele całkowicie oddzielonych domów/grup na jednym koncie.
- Role: `owner`, `admin`, `member`, `viewer`.
- Bezpieczna samodzielna rejestracja w trybach `open`, `invite_code` i `disabled`.
- Standardowe potwierdzenie e-maila Supabase przed aktywnym dostępem.
- Dom samodzielnie rejestrującego się użytkownika powstaje dopiero po potwierdzeniu e-maila.
- Admin/owner dodaje użytkownika po e-mailu przez bezpieczną Edge Function.
- Użytkownik utworzony przez admina musi uzupełnić profil i zmienić hasło.
- Wybór aktywnego domu dla kont należących do wielu grup.
- Szybka lista, parser ilości/jednostek i automatyczna kategoryzacja.
- Prywatne zdjęcia produktów z podpisanymi URL-ami; kompresja WebP pozostaje bez zmian.
- RLS i triggery blokujące dostęp oraz modyfikacje danych innych domów.

## Zmienione pliki

Nowe pliki:

- `supabase/migrations/20260603110000_secure_registration.sql`
- `supabase/functions/register-user/index.ts`
- `supabase/functions/finalize-registration/index.ts`
- `src/routes/confirm-email.tsx`
- `src/config/app.ts`
- `src/routes/whats-new.tsx`
- `src/theme/index.ts`
- `src/i18n/pl.ts`
- `src/i18n/en.ts`
- `src/i18n/index.ts`
- `.env.example`

Zmienione pliki:

- `supabase/functions/add-household-user/index.ts`
- `supabase/config.toml`
- `src/routes/login.tsx`
- `src/routes/about.tsx`
- `src/routes/privacy.tsx`
- `src/routes/settings.tsx`
- `src/routes/__root.tsx`
- `src/components/Brand.tsx`
- `src/components/BottomNav.tsx`
- `src/pages/ActiveListPage.tsx`
- `src/routes/add.tsx`
- `src/routes/quick-add.tsx`
- `src/routes/stores.tsx`
- `src/routes/receipts.tsx`
- `src/routes/household.tsx`
- `src/routes/select-household.tsx`
- `src/routes/history.tsx`
- `src/routes/item.$id.tsx`
- `src/routes/complete-profile.tsx`
- `src/routes/onboarding.tsx`
- `src/lib/error-page.ts`
- `public/manifest.webmanifest`
- `src/routes/onboarding.tsx`
- `src/pages/RequireAuth.tsx`
- `src/integrations/supabase/types.ts`
- `src/routeTree.gen.ts`
- `.env`
- `LOVEABLE_PATCH.md`

## Uzupełnienie: motyw i język aplikacji

W `src/routes/settings.tsx` dodano sekcję **Wygląd** z wyborem:

- `Auto` - korzysta z `prefers-color-scheme`,
- `Jasny` - wymusza jasny motyw,
- `Ciemny` - wymusza ciemny motyw.

Mechanizm znajduje się w `src/theme/index.ts`. Wybór zapisuje się w `localStorage` pod kluczem
`family-cart.theme`, działa od razu i przełącza istniejącą klasę Tailwind/shadcn `.dark` na
`document.documentElement`.

W `src/routes/settings.tsx` dodano też sekcję **Język aplikacji** z wyborem:

- `Polski`,
- `English`.

Mechanizm znajduje się w `src/i18n/index.ts`, a słowniki w `src/i18n/pl.ts` i `src/i18n/en.ts`.
Wybór zapisuje się lokalnie pod kluczem `family-cart.language`, ustawia `document.documentElement.lang`
i działa bez odświeżenia dla głównych ekranów.

Przetłumaczone lub częściowo przetłumaczone główne obszary:

- logowanie i rejestracja,
- ustawienia, wybór motywu i wybór języka,
- dolna nawigacja,
- ekran „O aplikacji”,
- nagłówki polityki prywatności,
- „Co nowego”,
- wybór domu/grupy,
- użytkownicy i role,
- lista zakupów, tryb zakupów, puste stany,
- dodawanie produktu i szybka lista,
- sklepy,
- paragony,
- historia,
- szczegóły produktu,
- onboarding, potwierdzenie e-maila i uzupełnienie profilu.

Nazwa aplikacji, wersja i autor nie są tłumaczone i zawsze pozostają:

```text
Family Cart
Version: v26.06.03.1
Created by: AutoSafe
```

TODO:

- pełne redakcyjne tłumaczenie długich paragrafów polityki prywatności,
- tłumaczenie nazw kategorii produktów i jednostek, jeśli aplikacja ma działać w pełni po angielsku,
- tłumaczenie tekstów zwracanych przez Supabase Edge Functions, jeśli mają być zależne od języka użytkownika.

## Test motywu i języka

Motyw:

1. Wejdź w `Ustawienia -> Wygląd`.
2. Wybierz `Ciemny` i sprawdź, czy aplikacja od razu przechodzi w ciemny tryb.
3. Odśwież aplikację i sprawdź, czy ciemny motyw został zachowany.
4. Wybierz `Jasny` i sprawdź wymuszenie jasnego motywu.
5. Wybierz `Auto`, zmień systemowe `prefers-color-scheme` i sprawdź, czy aplikacja reaguje.

Język:

1. Wejdź w `Ustawienia -> Język aplikacji`.
2. Domyślnie aplikacja powinna używać języka polskiego.
3. Wybierz `English` i sprawdź główne ekrany: logowanie, ustawienia, listę, dodawanie produktu,
   sklepy, paragony, domowników i szczegóły produktu.
4. Odśwież aplikację i sprawdź, czy język angielski został zachowany.
5. Sprawdź, że `Family Cart`, `Version: v26.06.03.1` i `Created by: AutoSafe` nie zmieniają się.

Wcześniejsza migracja `supabase/migrations/20260603090000_multi_households_roles_quick_list.sql`
pozostaje wymagana, ponieważ wprowadza model wielu domów, role, polityki RLS i słownik produktów.

## Migracja bezpiecznej rejestracji

`20260603110000_secure_registration.sql` dodaje:

- tabelę `registration_codes` z haszami kodów, limitami użyć i datą wygaśnięcia,
- tabelę `pending_registrations` z jednorazowymi tokenami i oczekującą nazwą domu,
- trigger rejestracji blokujący pominięcie backendu,
- funkcję `finalize_self_registration`,
- sprawdzanie potwierdzenia e-maila w funkcjach członkostwa i politykach dostępu.

## Edge Functions

- `register-user` obsługuje publiczną rejestrację i backendowy tryb rejestracji.
- `finalize-registration` tworzy dom dopiero po potwierdzeniu e-maila.
- `add-household-user` zachowuje model dodawania kont przez ownera/admina i wystawia bezpieczny token dla triggera.
- `complete-profile` pozostaje funkcją obowiązkowego uzupełnienia profilu i zmiany hasła.

## Jak działa bezpieczna rejestracja

Frontend nie wywołuje `supabase.auth.signUp()` bezpośrednio. Publiczna Edge Function `register-user`:

1. Sprawdza backendowy `REGISTRATION_MODE`.
2. W trybie `invite_code` sprawdza wyłącznie hasz kodu zapisany w bazie.
3. Tworzy jednorazowy, losowy token rejestracji i zapisuje tylko jego SHA-256.
4. Wywołuje standardowy Supabase Auth `signUp`, który wysyła e-mail potwierdzający.

Trigger `handle_new_user()` blokuje utworzenie konta aplikacji bez ważnego tokenu backendowego. Bezpośrednie wywołanie Auth `signUp` z pominięciem Edge Function nie przejdzie.

Po pierwszym logowaniu potwierdzonego użytkownika Edge Function `finalize-registration` tworzy jego dom i członkostwo `owner`. Konta utworzone przez administratora mają już członkostwo, więc nie dostają automatycznie nowego domu.

## Wdrożenie w Loveable

1. Wgraj lub zsynchronizuj pliki patcha do projektu Loveable.
2. Połącz projekt z właściwym projektem Supabase/Lovable Cloud.
3. Zastosuj migracje:
   - `supabase/migrations/20260603090000_multi_households_roles_quick_list.sql`
   - `supabase/migrations/20260603110000_secure_registration.sql`
4. Wdróż Edge Functions:
   - `register-user`
   - `finalize-registration`
   - `add-household-user`
   - `complete-profile`
5. Opublikuj aplikację i sprawdź PWA na telefonie.

Przy użyciu Supabase CLI:

```bash
supabase db push
supabase functions deploy register-user --no-verify-jwt
supabase functions deploy finalize-registration
supabase functions deploy add-household-user
supabase functions deploy complete-profile
```

## Wymagane ustawienia Supabase Auth

W panelu Supabase otwórz **Authentication → Providers → Email** i:

1. Włącz logowanie e-mail/hasło.
2. Włącz **Confirm email**.
3. Dodaj adres produkcyjnej aplikacji do dozwolonych redirect URLs.
4. Sprawdź szablon wiadomości potwierdzającej rejestrację.

`VITE_EMAIL_CONFIRMATION_REQUIRED=true` steruje komunikatem w UI, ale właściwe wymaganie potwierdzenia musi być włączone w panelu Supabase Auth.

## Zmienne środowiskowe

Frontend:

```env
VITE_REGISTRATION_MODE=open
VITE_EMAIL_CONFIRMATION_REQUIRED=true
```

Backendowa Edge Function `register-user`:

```env
REGISTRATION_MODE=open
APP_URL=https://twoja-domena.example
```

Dozwolone wartości: `open`, `invite_code`, `disabled`.

`REGISTRATION_MODE` jest źródłem prawdy i musi odpowiadać `VITE_REGISTRATION_MODE`. Zmiana samej zmiennej frontendowej nie zmienia zabezpieczeń backendu.
Nieznana wartość trybu jest traktowana jak `disabled`.

`APP_URL` jest opcjonalnym, ale zalecanym adresem aplikacji używanym przez backend jako cel linku potwierdzającego. Nie jest przyjmowany z formularza rejestracji, więc wywołujący nie może podmienić adresu przekierowania.

Edge Functions korzystają też ze standardowych sekretów dostarczanych przez Supabase:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Nigdy nie dodawaj `SUPABASE_SERVICE_ROLE_KEY`, kodów rejestracyjnych ani ich niezaszyfrowanych wartości do `VITE_*`, kodu React lub repozytorium.

## Tryby rejestracji

### `open`

Każdy może wypełnić formularz, ale aktywny dostęp oraz utworzenie domu następują dopiero po potwierdzeniu e-maila.

### `invite_code`

Formularz pokazuje pole kodu. Kod jest sprawdzany w Edge Function względem tabeli `registration_codes`.

Przykład utworzenia kodu w SQL Editorze z placeholderem, który trzeba zastąpić własną wartością
poza repozytorium:

```sql
insert into public.registration_codes (code_hash, label, max_uses, expires_at)
values (
  encode(extensions.digest('<KOD_USTAWIANY_POZA_REPOZYTORIUM>', 'sha256'), 'hex'),
  'Kod rodzinny',
  10,
  now() + interval '30 days'
);
```

W aplikacji użytkownik wpisuje kod przekazany poza repozytorium, a baza przechowuje wyłącznie hasz.

### `disabled`

Publiczny formularz rejestracji jest ukryty, a backend odrzuca próby samodzielnej rejestracji. Konta tworzy wyłącznie administrator istniejącego domu.

## RLS i dane

Migracje zabezpieczają istniejące tabele projektu:

- `profiles`
- `households`
- `household_members`
- `shopping_lists`
- `shopping_items`
- `item_photos`
- `activity_log`
- `household_product_dictionary`

Projekt nie zawiera obecnie tabel `favorites` ani `templates`. Gdy zostaną dodane, muszą posiadać `household_id` i analogiczne polityki członkostwa.

## Testy krok po kroku

1. Ustaw backend i frontend na `open`.
2. Załóż konto A z nazwą „Dom Piotra”. Sprawdź komunikat o potwierdzeniu e-maila.
3. Przed potwierdzeniem spróbuj się zalogować. Aplikacja powinna pokazać komunikat o konieczności potwierdzenia.
4. Potwierdź e-mail, zaloguj się i sprawdź automatyczne utworzenie domu oraz rolę ownera.
5. Załóż konto B z nazwą „Dom Marka”. Sprawdź, że nie widzi danych konta A.
6. Ustaw backend i frontend na `disabled`. Sprawdź ukryty formularz oraz komunikat.
7. Ustaw backend i frontend na `invite_code`. Sprawdź brak kodu, błędny kod, wygasły kod i poprawny kod.
8. Spróbuj wywołać Supabase Auth `signUp` bez Edge Function. Trigger powinien zablokować utworzenie konta aplikacji.
9. Jako owner domu A dodaj nowy e-mail z hasłem tymczasowym.
10. Zaloguj się nowym kontem i sprawdź obowiązkowy ekran uzupełnienia imienia, nazwiska i zmiany hasła.
11. Jako owner domu B dodaj ten sam e-mail. Sprawdź komunikat o istniejącym użytkowniku bez zmiany hasła.
12. Zaloguj się tym kontem i sprawdź ekran wyboru dwóch domów.
13. Spróbuj ręcznie odpytać lub zmienić rekord z obcym `household_id`; RLS powinien zablokować operację.
14. Wklej szybką listę z przykładami `mleko 2 szt`, `banany 1 kg`, `woda 6x`, `ser żółty 300g`.
15. Dodaj produkt ze zdjęciem i sprawdź miniaturę, podgląd oraz zapis skompresowanych plików WebP.
16. Sprawdź branding AutoSafe, politykę prywatności i układ PWA na telefonie.
17. Sprawdź w ustawieniach zapis motywu `Auto`, `Jasny`, `Ciemny` po odświeżeniu.
18. Sprawdź w ustawieniach zapis języka `Polski` / `English` po odświeżeniu.

## Słownik produktów

Migracja dodaje tabelę `household_product_dictionary` jako podstawę pod zapamiętywanie ręcznie wybranych kategorii w obrębie domu. Produkty dodane pojedynczo i przez szybką listę zapisują kategorię, jednostkę oraz domyślny sklep jako sugestię wyłącznie dla bieżącego domu.

## Uzupełnienie: sklepy, ceny, budżet i paragony

Nowa migracja:

- `supabase/migrations/20260603130000_stores_prices_receipts.sql`

Etap 1 jest gotowy w interfejsie:

- sklepy przypisane do domu,
- domyślny sklep listy i sklep produktu,
- ręczne ceny produktów oraz historia cen dla sklepu,
- szacowana wartość listy, budżet i pozostała kwota,
- grupowanie produktów według sklepu,
- słownik produktów oraz sugestie z aktywnego domu.

Etap 2 ma bezpieczną strukturę i ekran startowy:

- prywatne zdjęcia paragonów w bucketcie `receipt-images`,
- sklep, data, suma i status OCR,
- komunikat, że OCR wymaga weryfikacji użytkownika,
- brak automatycznego zapisywania cen bez potwierdzenia.

Do dalszego wdrożenia pozostają:

- właściwy proces OCR paragonu, ekran korekty pozycji i dopasowanie produktów,
- skaner kodów kreskowych,
- interfejs spiżarni i produktów cyklicznych,
- kolejka offline i synchronizacja,
- OCR listy zakupów ze zdjęcia,
- planowanie posiłków,
- porównanie sklepów na podstawie potwierdzonej historii cen.

Migracja dodaje RLS dla wszystkich nowych tabel i prywatnego storage paragonów. Przed testami end-to-end zastosuj ją przez `supabase db push`, a następnie sprawdź dostęp dwóch użytkowników z różnych domów.
