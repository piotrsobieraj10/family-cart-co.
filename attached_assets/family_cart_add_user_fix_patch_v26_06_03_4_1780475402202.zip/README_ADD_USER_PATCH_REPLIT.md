# Family Cart — poprawka dodawania użytkownika

Patch naprawia i uodparnia flow `Dodaj użytkownika` w aplikacji Family Cart.

## Co zmienia

- `supabase/functions/add-household-user/index.ts`
  - zwraca czytelne odpowiedzi `{ ok, code, error }`, żeby frontend nie pokazywał ogólnego błędu Edge Function,
  - pozwala dodać istniejący adres e-mail bez podawania hasła tymczasowego,
  - wymaga hasła tymczasowego tylko wtedy, gdy e-mail nie istnieje jeszcze w systemie,
  - sprawdza owner/admin aktualnego `household_id`,
  - nie ufa `user_id` z frontendu — bierze użytkownika z JWT,
  - najpierw szuka użytkownika po `profiles.email`, a dopiero potem przez Admin API `listUsers`,
  - tworzy / uzupełnia `profiles` przez `upsert`,
  - nie zmienia hasła istniejącego użytkownika,
  - obsługuje brak envów i błędy konfiguracji czytelnym komunikatem.

- `src/routes/household.tsx`
  - hasło tymczasowe nie jest już obowiązkowe przy każdym dodaniu,
  - formularz wyjaśnia, że hasło jest wymagane tylko dla nowego konta,
  - frontend obsługuje odpowiedź `{ ok:false, error }` z Edge Function i pokazuje prawdziwy powód błędu.

## Dlaczego

W aktualnym UI hasło tymczasowe było wymagane zawsze, nawet dla istniejącego użytkownika. Dodatkowo błędy Edge Function mogły być ukrywane jako ogólny błąd funkcji. Po tej poprawce:

- istniejący e-mail można dodać do kolejnego domu bez zmiany hasła,
- nowe konto nadal wymaga hasła tymczasowego,
- użytkownik widzi konkretny komunikat, np. brak uprawnień, niepotwierdzony e-mail, brak konfiguracji Edge Function albo wymagane hasło tymczasowe.

## Pliki w patchu

- `supabase/functions/add-household-user/index.ts`
- `src/routes/household.tsx`
- `README_ADD_USER_PATCH_REPLIT.md`
- `ADD_USER_PATCH_CHANGED_FILES.txt`

## Wdrożenie w Replit

1. Rozpakuj patch do katalogu tymczasowego.
2. Skopiuj pliki do projektu, zachowując ścieżki.
3. Wdróż ponownie Edge Function:

```bash
supabase functions deploy add-household-user
```

4. Upewnij się, że Edge Function ma ustawione sekrety:

```env
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

`SUPABASE_SERVICE_ROLE_KEY` nie może trafić do frontendu ani `VITE_*`.

## Testy

1. Owner/admin dodaje nowy e-mail bez hasła — aplikacja powinna pokazać, że hasło tymczasowe jest wymagane.
2. Owner/admin dodaje nowy e-mail z hasłem min. 6 znaków — konto powinno powstać i trafić do domu.
3. Owner/admin dodaje istniejący e-mail bez hasła — użytkownik powinien zostać dodany do domu bez zmiany hasła.
4. Member/viewer próbuje dodać użytkownika — operacja ma być zablokowana.
5. Ten sam użytkownik dodany drugi raz do tego samego domu — aplikacja ma pokazać, że już należy do grupy.
6. Konto owner/admin bez potwierdzonego e-maila — aplikacja ma pokazać komunikat o konieczności potwierdzenia e-maila.
